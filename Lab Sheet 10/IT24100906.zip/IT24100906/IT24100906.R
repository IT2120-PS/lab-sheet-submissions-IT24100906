getwd()
setwd("C:\\Users\\User\\Desktop\\IT24101073")

snack_counts <- c(120, 95, 85, 100)
expected_prob <- c(0.25, 0.25, 0.25, 0.25)
test_result <- chisq.test(snack_counts, p = expected_prob)
print(test_result)
if (test_result$p.value < 0.05) {
  print("Conclusion: Reject H0. Snack types are NOT chosen equally.")
} else {
  print("Conclusion: Fail to reject H0. Snack types ARE chosen equally.")
}